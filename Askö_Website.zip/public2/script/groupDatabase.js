let table;

$(document).ready(function () {
    fetch('/api/members')
        .then(res => res.json())
        .then(data => {
            table = $('#membersList').DataTable({
                data: data,
                columns: [
                    { data: 'id' },
                    { data: 'name' },
                    { data: 'surname' },
                    { data: 'birthday' },
                    { data: 'address' },
                    { data: 'plz' },
                    { data: 'city' },
                    { data: 'activeMember' },
                    {
                        data: null,
                        orderable: false,
                        render: function (data, type, row) {
                            return `
                                <button class="delete-btn" data-id="${row.id}">Löschen</button>
                            `;
                        }
                    }
                ]
            });
        })
        .catch(err => console.error('Fehler beim Laden:', err));

    // Add Member Button
    $('#addMemberBtn').click(() => {
        if ($('#name').val() != "" && $('#surname').val() != "" && $('#birthday').val() != "" //&& isValidDate($('#birthday').val())
        && $('#address').val() != "" && $('#plz').val() != "" && isNumber($('plz').val()) && $('#city').val() != "" 
        && $('#activeMember').val() != "Auswählen") {
            const newMember = {
                name: $('#name').val(),
                surname: $('#surname').val(),
                birthday: $('#birthday').val(),
                address: $('#address').val(),
                plz: $('#plz').val(),
                city: $('#city').val(),
                activeMember: $('#activeMember').val()
            };

            fetch('/api/members', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newMember)
            })
                .then(res => res.json())
                .then(data => {
                    table.row.add(data).draw(); // neuen Eintrag in die Tabelle hinzufügen
                    // Optional: Formular zurücksetzen
                    $('#addMemberForm input').val('');
                    $('#activeMember').val('Auswählen');
                })
                .catch(err => console.error('Fehler beim Hinzufügen:', err));
        }
    });

    // Delegiertes Event, da die Tabelle dynamisch ist
    $('#membersList').on('click', '.delete-btn', function () {
        const id = $(this).data('id');
        const row = table.row($(this).parents('tr'));

            fetch(`/api/members/${id}`, { method: 'DELETE' })
                .then(res => {
                    if (!res.ok) throw new Error('Fehler beim Löschen');
                    return res.json();
                })
                .then(() => {
                    row.remove().draw(); // Sofort aus der Tabelle löschen
                })
                .catch(err => alert('Fehler: ' + err.message));
    });
});

function isNumber(num) {
    return true;
}