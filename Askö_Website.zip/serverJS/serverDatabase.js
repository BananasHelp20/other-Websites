const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();

const memberDataPath = path.join(__dirname, 'json/memberData.json');

app.use(express.static(path.join(__dirname, '../public2')));
app.use(express.json());

// GET /api/members -> Datei jedes Mal frisch einlesen
app.get('/api/members', (req, res) => {
    fs.readFile(memberDataPath, 'utf8', (err, data) => {
        if (err) {
            console.error('Fehler beim Lesen der Datei:', err);
            return res.status(500).json({ message: 'Fehler beim Laden' });
        }
        res.json(JSON.parse(data));
    });
});

// POST /api/members -> wie vorher, nur File schreiben
app.post('/api/members', (req, res) => {
    fs.readFile(memberDataPath, 'utf8', (err, fileData) => {
        if (err) return res.status(500).json({ message: 'Fehler beim Laden' });

        let members = JSON.parse(fileData);
        const newMember = req.body;
        const lastId = members.length ? members[members.length - 1].id : 0;
        newMember.id = lastId + 1;
        members.push(newMember);

        fs.writeFile(memberDataPath, JSON.stringify(members, null, 2), (err) => {
            if (err) return res.status(500).json({ message: 'Fehler beim Speichern' });
            res.status(201).json(newMember);
        });
    });
});

// DELETE /api/members/:id
app.delete('/api/members/:id', (req, res) => {
    const id = parseInt(req.params.id);

    fs.readFile(memberDataPath, 'utf8', (err, fileData) => {
        if (err) return res.status(500).json({ message: 'Fehler beim Laden' });

        let members = JSON.parse(fileData);
        const newMembers = members.filter(m => m.id !== id);

        if (newMembers.length === members.length) {
            return res.status(404).json({ message: 'Mitglied nicht gefunden' });
        }

        fs.writeFile(memberDataPath, JSON.stringify(newMembers, null, 2), (err) => {
            if (err) return res.status(500).json({ message: 'Fehler beim Speichern' });
            res.json({ message: 'Mitglied gelöscht' });
        });
    });
});

app.listen(3000, () => {
    console.log('Server läuft auf http://localhost:3000');
});